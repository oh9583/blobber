package common

type ProviderType byte

const (
	ProviderTypeBlobber ProviderType = iota
	ProviderTypeValidator
)
