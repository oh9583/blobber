package handler

//Need to check for errors here
// func TestBlobberGRPCService_UploadFile(t *testing.T) {
// 	mp := filepath.Join(os.TempDir(), "/test_ul_files")
// 	if err := os.MkdirAll(mp, os.ModePerm); err != nil {
// 		t.Fatal(err)
// 	}
// 	if err := setupMockForFileManager(); err != nil {
// 		t.Fatal(err)
// 	}
// 	if err := setupFileManager(mp); err != nil {
// 		t.Fatal(err)
// 	}

// 	bClient, tdController := setupGrpcTests(t)
// 	allocationTx := randString(32)

// 	pubKey, _, signScheme := GeneratePubPrivateKey(t)
// 	clientSignature, _ := signScheme.Sign(encryption.Hash(allocationTx))
// 	pubKeyBytes, _ := hex.DecodeString(pubKey)
// 	clientId := encryption.Hash(pubKeyBytes)

// 	path := "/some_file"
// 	formFieldByt, err := json.Marshal(&allocation.UpdateFileChanger{BaseFileChanger: allocation.BaseFileChanger{Filename: `helper_integration_test.go`, Path: path}})
// 	if err != nil {
// 		t.Fatal(err)
// 	}

// 	if err := tdController.AddUploadTestData(allocationTx, pubKey, clientId); err != nil {
// 		t.Fatal(err)
// 	}

// 	file, err := os.CreateTemp(mp, "test*")
// 	if err != nil {
// 		t.Fatal(err)
// 	}
// 	defer file.Close()
// 	stats, err := file.Stat()
// 	if err != nil {
// 		panic(err)
// 	}
// 	fileB := make([]byte, stats.Size())
// 	if _, err := io.ReadFull(file, fileB); err != nil {
// 		t.Fatal(err)
// 	}

// 	testCases := []struct {
// 		name             string
// 		context          metadata.MD
// 		input            *blobbergrpc.UploadFileRequest
// 		expectedFileName string
// 		expectingError   bool
// 	}{
// 		{
// 			name: "Success",
// 			context: metadata.New(map[string]string{
// 				common.ClientHeader:          clientId,
// 				common.ClientSignatureHeader: clientSignature,
// 				common.ClientKeyHeader:       pubKey,
// 			}),

// 			input: &blobbergrpc.UploadFileRequest{
// 				Allocation:          allocationTx,
// 				Path:                path,
// 				ConnectionId:        "connection_id",
// 				Method:              "POST",
// 				UploadMeta:          string(formFieldByt),
// 				UpdateMeta:          "",
// 				UploadFile:          fileB,
// 				UploadThumbnailFile: []byte{},
// 			},
// 			expectedFileName: "helper_integration_test.go",
// 			expectingError:   false,
// 		},
// 		{
// 			name: "Fail",
// 			context: metadata.New(map[string]string{
// 				common.ClientHeader:          clientId,
// 				common.ClientSignatureHeader: clientSignature,
// 				common.ClientKeyHeader:       pubKey,
// 			}),
// 			input: &blobbergrpc.UploadFileRequest{
// 				Allocation:          "",
// 				Path:                "",
// 				ConnectionId:        "",
// 				Method:              "",
// 				UploadMeta:          "",
// 				UpdateMeta:          "",
// 				UploadFile:          nil,
// 				UploadThumbnailFile: nil,
// 			},
// 			expectedFileName: "",
// 			expectingError:   true,
// 		},
// 	}

// 	for _, tc := range testCases {
// 		ctx := context.Background()
// 		ctx = metadata.NewOutgoingContext(ctx, tc.context)
// 		response, err := bClient.UploadFile(ctx, tc.input)
// 		if err != nil {
// 			if !tc.expectingError {
// 				t.Fatal(err)
// 			}

// 			continue
// 		}

// 		if tc.expectingError {
// 			t.Fatal("expected error")
// 		}

// 		if response.GetFilename() != tc.expectedFileName {
// 			t.Fatal("failed!")
// 		}
// 	}
// }
