package reference

const (
	TableNameReferenceObjects = "reference_objects"
)
